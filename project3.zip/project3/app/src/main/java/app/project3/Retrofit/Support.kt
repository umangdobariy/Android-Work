package app.project3.Retrofit

data class Support(
    var Url:String,
    var text:String
) {

}