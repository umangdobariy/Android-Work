package app.statussaver.savestatus.model

data class saveStatusModel(var img:Int) {

}