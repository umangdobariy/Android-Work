package app.statussaver.savestatus.model

import android.graphics.drawable.Icon

data class NavigationModel(var icon: Int,var title:String) {
}